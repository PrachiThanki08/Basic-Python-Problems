print("Student Name:")

'''
print("Address:")
print("Contact_No:")
print("Mother Tongue:")
'''

print("School_Name:")
print("Year:")
print("Panel:")
print("Roll_No:")